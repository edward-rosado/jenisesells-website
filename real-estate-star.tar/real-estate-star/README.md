# Real Estate Star — Website

## Files

```
index.html          ← Open this in a browser
logo.svg            ← Standalone logo asset
assets/
  fraunces.woff2    ← Display serif (title)
  intertight.woff2  ← Light sans (subtitle)
  inter.woff2       ← Body sans
  three.module.min.js
  three.core.min.js ← 3D wireframe house engine
```

## Viewing

**Local file:** ES modules require a server. From this folder run any static server:

```bash
python3 -m http.server 8000
# → http://localhost:8000
```

Or just drop the folder onto any static host (Netlify, Cloudflare Pages, GitHub Pages).

## Design System

| Token | Value | Role |
|---|---|---|
| `--sage-400` | `#9caf88` | Primary — pale sage green |
| `--ground` | `#fafbf8` | Page surface |
| `--ink` | `#242a1f` | Primary text |
| Fraunces 340 / opsz 144 | | Display — thin serif, heavy stems |
| Inter Tight 300 / -0.025em | | Subtitle — light sans, tight kerning |
| Inter 400 | | Body |

## Logo

Emblematic square with tab-cut extensions, a punched center window, and five
points positioned on a tilted orbital ellipse. Single-color, scales 16px → ∞.

## 3D Hero Scene

Three.js wireframe house built from an explicit edge list (body, gabled roof
with overhang, chimney, door, two mullioned windows) sitting on a faint grid.
Three tilted orbit rings carry twelve traveling nodes, each dynamically linked
to its nearest house anchor. House rotation lerps toward the cursor position
for a smooth mouse-move parallax.
